import re
from anytree import Node, RenderTree


class LL1Parser:
    def __init__(self):
        self.parsing_table = {
            'E': {'num': ['T', 'E\''], '(': ['T', 'E\'']},
            'E\'': {'+': ['+', 'T', 'E\''], ')': [], '$': []},
            'T': {'num': ['F', 'T\''], '(': ['F', 'T\'']},
            'T\'': {'+': [], '*': ['*', 'F', 'T\''], ')': [], '$': []},
            'F': {'num': ['num'], '(': ['(', 'E', ')']}
        }
        self.terminals = ['num', '+', '*', '(', ')', '$']
        self.non_terminals = ['E', 'E\'', 'T', 'T\'', 'F']
        self.start_symbol = 'E'

    def parse(self, tokens):
        stack = ['$']
        stack.append(self.start_symbol)
        tokens.append('$')  # End of input symbol

        i = 0
        while stack:
            top = stack.pop()
            current_token = tokens[i]

            if top in self.terminals:
                if top == current_token:
                    i += 1
                else:
                    return False
            elif top in self.non_terminals:
                if current_token in self.parsing_table[top]:
                    production = self.parsing_table[top][current_token]
                    stack.extend(reversed(production))
                else:
                    return False
            else:
                return False
        return i == len(tokens)

    def build_parse_tree(self, tokens):
        tokens.append('$')  # End of input symbol
        stack = ['$']
        stack.append(self.start_symbol)
        root = Node(self.start_symbol)
        current_node = root
        parent_stack = [root]

        i = 0
        while stack:
            top = stack.pop()
            current_token = tokens[i]

            if top in self.terminals:
                if top == current_token:
                    Node(top, parent=current_node)
                    i += 1
                    if parent_stack:
                        current_node = parent_stack.pop()
                else:
                    return None
            elif top in self.non_terminals:
                if current_token in self.parsing_table[top]:
                    production = self.parsing_table[top][current_token]
                    current_node = Node(top, parent=parent_stack[-1])
                    parent_stack.append(current_node)
                    for symbol in reversed(production):
                        stack.append(symbol)
            else:
                return None
        return root


def tokenize(input_string):
    token_specification = [
        ('num', r'\d+'),  # Numbers
        ('OP_PLUS', r'\+'),  # Addition operator
        ('OP_MULT', r'\*'),  # Multiplication operator
        ('LPAREN', r'\('),  # Left parenthesis
        ('RPAREN', r'\)'),  # Right parenthesis
        ('SKIP', r'[ \t]+'),  # Skip over spaces and tabs
        ('MISMATCH', r'.'),  # Any other character
    ]
    token_regex = '|'.join(f'(?P<{pair[0]}>{pair[1]})' for pair in token_specification)
    get_token = re.compile(token_regex).match
    line = input_string
    match = get_token(line)
    tokens = []
    while match is not None:
        typ = match.lastgroup
        if typ == 'num':
            tokens.append('num')
        elif typ == 'OP_PLUS':
            tokens.append('+')
        elif typ == 'OP_MULT':
            tokens.append('*')
        elif typ == 'LPAREN':
            tokens.append('(')
        elif typ == 'RPAREN':
            tokens.append(')')
        elif typ == 'SKIP':
            pass
        elif typ == 'MISMATCH':
            raise RuntimeError(f'{match.group(typ)} unexpected on line')
        match = get_token(line, match.end())
    return tokens


def main():
    input_string = input("Enter the expression to be parsed: ")
    input_tokens = tokenize(input_string)
    print("Tokens:", input_tokens)
    parser = LL1Parser()
    is_valid = parser.parse(input_tokens.copy())
    parse_tree = parser.build_parse_tree(input_tokens.copy())
    print("\nParsing Table:")
    for non_terminal in parser.non_terminals:
        row = f"{non_terminal}: "
        for terminal in parser.terminals:
            if terminal in parser.parsing_table[non_terminal]:
                production = " ".join(parser.parsing_table[non_terminal][terminal])
                row += f"{terminal}: {production}\t"
            else:
                row += f"{terminal}: \t"
        print(row)
    print("\nInput is valid:", is_valid)
    print("\nParse tree:")
    if parse_tree:
        for pre, fill, node in RenderTree(parse_tree):
            print("%s%s" % (pre, node.name))
    else:
        print("Invalid parse tree")


if __name__ == "__main__":
    main()
